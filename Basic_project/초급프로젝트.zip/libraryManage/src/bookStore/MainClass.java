package bookStore;

public class MainClass {
	public static void main(String[] args) {
		ViewClass vc = new ViewClass();
		vc.startMethod();
	}
}
