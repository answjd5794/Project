package bookStore;

public class BooksVO {

   public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_pub_name() {
		return book_pub_name;
	}
	public void setBook_pub_name(String book_pub_name) {
		this.book_pub_name = book_pub_name;
	}
	public String getBook_writer() {
		return book_writer;
	}
	public void setBook_writer(String book_writer) {
		this.book_writer = book_writer;
	}
	public String getBook_pub_date() {
		return book_pub_date;
	}
	public void setBook_pub_date(String book_pub_date) {
		this.book_pub_date = book_pub_date;
	}
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int book_price) {
		this.book_price = book_price;
	}
	public String getBook_category() {
		return book_category;
	}
	public void setBook_category(String book_category) {
		this.book_category = book_category;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
private int book_id;
   private String book_name;
   private String book_pub_name;
   private String book_writer;
   private String book_pub_date;
   private int book_price;
   private String book_category;
   private int order_id;
   
   

   



   
}