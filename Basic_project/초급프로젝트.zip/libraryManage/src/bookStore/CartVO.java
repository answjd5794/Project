package bookStore;

public class CartVO {
	   // 장바구니
	   private String cart_id;

	   public String getCart_id() {
	      return cart_id;
	   }

	   public void setCart_id(String cart_id) {
	      this.cart_id = cart_id;
	   }
}

